/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionNew;
    QAction *actionOpen;
    QAction *actionSave;
    QAction *actionSave_As;
    QAction *actionCopy;
    QAction *actionCut;
    QAction *actionPaste;
    QAction *actionUndo;
    QAction *actionRedo;
    QWidget *centralWidget;
    QPushButton *pushButton;
    QTabWidget *tabWidget;
    QWidget *tab_Conexion;
    QGroupBox *groupBox;
    QFormLayout *formLayout;
    QLabel *label_4;
    QHBoxLayout *horizontalLayout;
    QComboBox *comboBox_puertos;
    QPushButton *button_refresh_ports;
    QLabel *label_5;
    QLineEdit *edit_estado;
    QPushButton *button_connect;
    QWidget *tab_ServerCom;
    QPlainTextEdit *txtReceive;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_4;
    QPushButton *btnClear;
    QSpacerItem *horizontalSpacer;
    QPushButton *btnSend;
    QPlainTextEdit *txtSend;
    QWidget *layoutWidget_2;
    QHBoxLayout *horizontalLayout_5;
    QLineEdit *txtIP;
    QLineEdit *txtPort;
    QPushButton *btnConnect;
    QPushButton *btnListen;
    QWidget *tab;
    QGraphicsView *graphicsView_4;
    QFrame *frame;
    QGraphicsView *graphicsView;
    QGraphicsView *graphicsView_2;
    QGraphicsView *graphicsView_6;
    QGraphicsView *graphicsView_5;
    QComboBox *comboBox;
    QGraphicsView *graphicsView_3;
    QMenuBar *menuBar;
    QMenu *menuFile;
    QMenu *menuEdit;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(904, 579);
        actionNew = new QAction(MainWindow);
        actionNew->setObjectName(QStringLiteral("actionNew"));
        QIcon icon;
        icon.addFile(QStringLiteral(":/Images/new.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionNew->setIcon(icon);
        actionOpen = new QAction(MainWindow);
        actionOpen->setObjectName(QStringLiteral("actionOpen"));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/Images/open.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionOpen->setIcon(icon1);
        actionSave = new QAction(MainWindow);
        actionSave->setObjectName(QStringLiteral("actionSave"));
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/Images/save.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionSave->setIcon(icon2);
        actionSave_As = new QAction(MainWindow);
        actionSave_As->setObjectName(QStringLiteral("actionSave_As"));
        QIcon icon3;
        icon3.addFile(QStringLiteral(":/Images/Save As.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionSave_As->setIcon(icon3);
        actionCopy = new QAction(MainWindow);
        actionCopy->setObjectName(QStringLiteral("actionCopy"));
        QIcon icon4;
        icon4.addFile(QStringLiteral(":/Images/copy.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionCopy->setIcon(icon4);
        actionCut = new QAction(MainWindow);
        actionCut->setObjectName(QStringLiteral("actionCut"));
        QIcon icon5;
        icon5.addFile(QStringLiteral(":/Images/cut.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionCut->setIcon(icon5);
        actionPaste = new QAction(MainWindow);
        actionPaste->setObjectName(QStringLiteral("actionPaste"));
        QIcon icon6;
        icon6.addFile(QStringLiteral(":/Images/paste.ico"), QSize(), QIcon::Normal, QIcon::Off);
        actionPaste->setIcon(icon6);
        actionUndo = new QAction(MainWindow);
        actionUndo->setObjectName(QStringLiteral("actionUndo"));
        QIcon icon7;
        icon7.addFile(QStringLiteral(":/Images/Deshacer.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionUndo->setIcon(icon7);
        actionRedo = new QAction(MainWindow);
        actionRedo->setObjectName(QStringLiteral("actionRedo"));
        QIcon icon8;
        icon8.addFile(QStringLiteral(":/Images/Rehacer.png"), QSize(), QIcon::Normal, QIcon::Off);
        actionRedo->setIcon(icon8);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(-200, 200, 75, 23));
        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(10, 10, 881, 491));
        tabWidget->setTabBarAutoHide(false);
        tab_Conexion = new QWidget();
        tab_Conexion->setObjectName(QStringLiteral("tab_Conexion"));
        groupBox = new QGroupBox(tab_Conexion);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(60, 30, 331, 131));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(groupBox->sizePolicy().hasHeightForWidth());
        groupBox->setSizePolicy(sizePolicy);
        groupBox->setMinimumSize(QSize(300, 0));
        formLayout = new QFormLayout(groupBox);
        formLayout->setSpacing(6);
        formLayout->setContentsMargins(11, 11, 11, 11);
        formLayout->setObjectName(QStringLiteral("formLayout"));
        formLayout->setFieldGrowthPolicy(QFormLayout::ExpandingFieldsGrow);
        label_4 = new QLabel(groupBox);
        label_4->setObjectName(QStringLiteral("label_4"));

        formLayout->setWidget(1, QFormLayout::LabelRole, label_4);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        comboBox_puertos = new QComboBox(groupBox);
        comboBox_puertos->setObjectName(QStringLiteral("comboBox_puertos"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(comboBox_puertos->sizePolicy().hasHeightForWidth());
        comboBox_puertos->setSizePolicy(sizePolicy1);
        comboBox_puertos->setEditable(false);

        horizontalLayout->addWidget(comboBox_puertos);

        button_refresh_ports = new QPushButton(groupBox);
        button_refresh_ports->setObjectName(QStringLiteral("button_refresh_ports"));

        horizontalLayout->addWidget(button_refresh_ports);


        formLayout->setLayout(1, QFormLayout::FieldRole, horizontalLayout);

        label_5 = new QLabel(groupBox);
        label_5->setObjectName(QStringLiteral("label_5"));

        formLayout->setWidget(2, QFormLayout::LabelRole, label_5);

        edit_estado = new QLineEdit(groupBox);
        edit_estado->setObjectName(QStringLiteral("edit_estado"));
        edit_estado->setAlignment(Qt::AlignCenter);
        edit_estado->setReadOnly(true);

        formLayout->setWidget(2, QFormLayout::FieldRole, edit_estado);

        button_connect = new QPushButton(groupBox);
        button_connect->setObjectName(QStringLiteral("button_connect"));

        formLayout->setWidget(3, QFormLayout::FieldRole, button_connect);

        tabWidget->addTab(tab_Conexion, QString());
        tab_ServerCom = new QWidget();
        tab_ServerCom->setObjectName(QStringLiteral("tab_ServerCom"));
        txtReceive = new QPlainTextEdit(tab_ServerCom);
        txtReceive->setObjectName(QStringLiteral("txtReceive"));
        txtReceive->setGeometry(QRect(50, 62, 588, 191));
        txtReceive->setReadOnly(true);
        layoutWidget = new QWidget(tab_ServerCom);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(50, 370, 591, 25));
        horizontalLayout_4 = new QHBoxLayout(layoutWidget);
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        btnClear = new QPushButton(layoutWidget);
        btnClear->setObjectName(QStringLiteral("btnClear"));

        horizontalLayout_4->addWidget(btnClear);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer);

        btnSend = new QPushButton(layoutWidget);
        btnSend->setObjectName(QStringLiteral("btnSend"));
        btnSend->setEnabled(false);

        horizontalLayout_4->addWidget(btnSend);

        txtSend = new QPlainTextEdit(tab_ServerCom);
        txtSend->setObjectName(QStringLiteral("txtSend"));
        txtSend->setGeometry(QRect(50, 260, 588, 101));
        txtSend->setMaximumSize(QSize(16777215, 150));
        layoutWidget_2 = new QWidget(tab_ServerCom);
        layoutWidget_2->setObjectName(QStringLiteral("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(55, 30, 581, 25));
        horizontalLayout_5 = new QHBoxLayout(layoutWidget_2);
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        txtIP = new QLineEdit(layoutWidget_2);
        txtIP->setObjectName(QStringLiteral("txtIP"));

        horizontalLayout_5->addWidget(txtIP);

        txtPort = new QLineEdit(layoutWidget_2);
        txtPort->setObjectName(QStringLiteral("txtPort"));

        horizontalLayout_5->addWidget(txtPort);

        btnConnect = new QPushButton(layoutWidget_2);
        btnConnect->setObjectName(QStringLiteral("btnConnect"));

        horizontalLayout_5->addWidget(btnConnect);

        btnListen = new QPushButton(layoutWidget_2);
        btnListen->setObjectName(QStringLiteral("btnListen"));

        horizontalLayout_5->addWidget(btnListen);

        tabWidget->addTab(tab_ServerCom, QString());
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        graphicsView_4 = new QGraphicsView(tab);
        graphicsView_4->setObjectName(QStringLiteral("graphicsView_4"));
        graphicsView_4->setGeometry(QRect(450, 130, 104, 104));
        graphicsView_4->setStyleSheet(QStringLiteral("background-image: url(:/Imagenes/flechaderecha.png);"));
        frame = new QFrame(tab);
        frame->setObjectName(QStringLiteral("frame"));
        frame->setGeometry(QRect(57, 127, 110, 110));
        frame->setFrameShape(QFrame::WinPanel);
        frame->setFrameShadow(QFrame::Plain);
        frame->setLineWidth(5);
        graphicsView = new QGraphicsView(tab);
        graphicsView->setObjectName(QStringLiteral("graphicsView"));
        graphicsView->setGeometry(QRect(60, 130, 104, 104));
        graphicsView->setStyleSheet(QStringLiteral("background-image: url(:/Imagenes/flecha.png);"));
        graphicsView_2 = new QGraphicsView(tab);
        graphicsView_2->setObjectName(QStringLiteral("graphicsView_2"));
        graphicsView_2->setGeometry(QRect(320, 130, 104, 104));
        graphicsView_2->setStyleSheet(QStringLiteral("background-image: url(:/Imagenes/flechaizquierda.png);"));
        graphicsView_6 = new QGraphicsView(tab);
        graphicsView_6->setObjectName(QStringLiteral("graphicsView_6"));
        graphicsView_6->setGeometry(QRect(710, 130, 104, 104));
        graphicsView_6->setStyleSheet(QStringLiteral("background-image: url(:/Imagenes/lapiz arriba.jpg);"));
        graphicsView_5 = new QGraphicsView(tab);
        graphicsView_5->setObjectName(QStringLiteral("graphicsView_5"));
        graphicsView_5->setGeometry(QRect(580, 130, 104, 104));
        graphicsView_5->setStyleSheet(QStringLiteral("background-image: url(:/Imagenes/lapiz abajo.jpg);"));
        comboBox = new QComboBox(tab);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(180, 310, 69, 22));
        graphicsView_3 = new QGraphicsView(tab);
        graphicsView_3->setObjectName(QStringLiteral("graphicsView_3"));
        graphicsView_3->setGeometry(QRect(190, 130, 104, 104));
        graphicsView_3->setStyleSheet(QLatin1String("\n"
"background-image: url(:/Imagenes/flechaabajo.png);"));
        tabWidget->addTab(tab, QString());
        MainWindow->setCentralWidget(centralWidget);
        tabWidget->raise();
        pushButton->raise();
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 904, 21));
        menuFile = new QMenu(menuBar);
        menuFile->setObjectName(QStringLiteral("menuFile"));
        menuEdit = new QMenu(menuBar);
        menuEdit->setObjectName(QStringLiteral("menuEdit"));
        MainWindow->setMenuBar(menuBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(menuFile->menuAction());
        menuBar->addAction(menuEdit->menuAction());
        menuFile->addAction(actionNew);
        menuFile->addAction(actionOpen);
        menuFile->addAction(actionSave);
        menuFile->addAction(actionSave_As);
        menuEdit->addAction(actionCopy);
        menuEdit->addAction(actionCut);
        menuEdit->addAction(actionPaste);
        menuEdit->addSeparator();
        menuEdit->addAction(actionUndo);
        menuEdit->addAction(actionRedo);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Impresora 2D", Q_NULLPTR));
        actionNew->setText(QApplication::translate("MainWindow", "New", Q_NULLPTR));
        actionOpen->setText(QApplication::translate("MainWindow", "Open", Q_NULLPTR));
        actionSave->setText(QApplication::translate("MainWindow", "Save", Q_NULLPTR));
        actionSave_As->setText(QApplication::translate("MainWindow", "Save As", Q_NULLPTR));
        actionCopy->setText(QApplication::translate("MainWindow", "Copy", Q_NULLPTR));
        actionCut->setText(QApplication::translate("MainWindow", "Cut", Q_NULLPTR));
        actionPaste->setText(QApplication::translate("MainWindow", "Paste", Q_NULLPTR));
        actionUndo->setText(QApplication::translate("MainWindow", "Undo", Q_NULLPTR));
        actionRedo->setText(QApplication::translate("MainWindow", "Redo", Q_NULLPTR));
        pushButton->setText(QApplication::translate("MainWindow", "PushButton", Q_NULLPTR));
        groupBox->setTitle(QApplication::translate("MainWindow", "Conexi\303\263n", Q_NULLPTR));
        label_4->setText(QApplication::translate("MainWindow", "Puerto Serie", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        button_refresh_ports->setToolTip(QApplication::translate("MainWindow", "Refrescar puertos", Q_NULLPTR));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_STATUSTIP
        button_refresh_ports->setStatusTip(QApplication::translate("MainWindow", "Refrescar puertos", Q_NULLPTR));
#endif // QT_NO_STATUSTIP
        button_refresh_ports->setText(QApplication::translate("MainWindow", "Actualizar", Q_NULLPTR));
        label_5->setText(QApplication::translate("MainWindow", "Estado", Q_NULLPTR));
        button_connect->setText(QApplication::translate("MainWindow", "Conectar", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_Conexion), QApplication::translate("MainWindow", "Estableciendo Conexion", Q_NULLPTR));
        btnClear->setText(QApplication::translate("MainWindow", "Clear", Q_NULLPTR));
        btnSend->setText(QApplication::translate("MainWindow", "Send", Q_NULLPTR));
        txtIP->setText(QApplication::translate("MainWindow", "127.0.0.1", Q_NULLPTR));
        txtPort->setText(QApplication::translate("MainWindow", "3000", Q_NULLPTR));
        btnConnect->setText(QApplication::translate("MainWindow", "Connect", Q_NULLPTR));
        btnListen->setText(QApplication::translate("MainWindow", "Listen", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_ServerCom), QApplication::translate("MainWindow", "Comunicacion Server", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("MainWindow", "Interfaz", Q_NULLPTR));
        menuFile->setTitle(QApplication::translate("MainWindow", "File", Q_NULLPTR));
        menuEdit->setTitle(QApplication::translate("MainWindow", "Edit", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
