/*
===============================================================================
 Name        : TPO.c
 Author      : $(author)
 Version     :
 Copyright   : $(copyright)
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC17xx.h"
#endif

#include <cr_section_macros.h>
#include "Infotronic.h"
#include "Inicializacion.h"
#include "stdio.h"

#define 	ESPERANDO 		0
#define 	RECIBIENDO		1
#define 	IMPRIMIENDO		2
#define		FINALIZADO		3
#define 	ERROR 			-1

/*  DESBICCER  */
#define 	UP				49
#define 	DOWN			50
#define 	ADELANTE		51
#define 	ATRAS			52
#define 	IZQUIERDA		53
#define 	DERECHA			54
#define 	NEUTRO			55

void testServo( void );
void teststepper ( void );
void Impresora( void );
void Desbiccer( void );

int main(void) {

		Inicializacion();


		while(1)
		{

			Desbiccer();

//			testServo();
//			teststepper();
			TimerEvent();
		}
		return 0;
}


void Desbiccer( void ){
	static uint8_t estado = 0;
	uint8_t aux;
	uint8_t Accion;

//	static uint8_t estadoAnterior = 0, tecla = 0, lapiz = 0;
//	tecla = GetKey();
//	if( tecla == 255 ){
//		tecla = estadoAnterior;
//	}
//	else{
//		estadoAnterior = tecla;
//	}
//	switch(tecla){
//	case 1:
//		if(lapiz == 0){
//			Grip(SUBIR);
//			lapiz = 1;
//		}
//		else{
//			Grip(BAJAR);
//			lapiz = 0;
//		}
//		break;
//	case 2:
//		m1step(0);
//		break;qt
//	case 3:
//		m1step(1);
//		break;
//	case 4:
//		m2step(0);
//		break;
//	case 5:
//		m2step(1);
//		break;
//	}

	switch( estado ){

	case ESPERANDO:
		aux = Pop_RX();
		if( aux == '#' ){		//Si llega el comienzo de una linea
			estado = RECIBIENDO;
			sofar = 0;			//Posiciono el flag de buffer al comienzo del mismo

		}
		break;

	case RECIBIENDO:
		aux = Pop_RX();
		if( aux != 255 && aux != '$' ){	//Si hay dato y no es el final de trama
			buffer[sofar] = aux;		//Lo guardo
			sofar++;					//Aumento el flag
		}
		if( aux == '$' ){				//Si llega el final de trama
			buffer[sofar] = ' ';
			sofar++;
			buffer[sofar] = '\n';
			sofar++;
			estado = IMPRIMIENDO;
		}
		break;

	case IMPRIMIENDO:
		if(buffer[0]=='#'){
			Accion = buffer[3];

		}
		else{
			Accion = buffer[2];

		}
		if( Accion !=  NEUTRO ){
			switch( Accion ){

		case UP:
			Grip(SUBIR);
			break;

		case DOWN:
			Grip(BAJAR);
			break;

		case ADELANTE:
			m1step(0);
			m1step(0);
			m1step(0);
			m1step(0);
			m1step(0);
			m1step(0);
			m1step(0);
			m1step(0);
			m1step(0);
			m1step(0);
			break;

		case ATRAS:
			m1step(1);
			m1step(1);
			m1step(1);
			m1step(1);
			m1step(1);
			m1step(1);
			m1step(1);
			m1step(1);
			m1step(1);
			m1step(1);
			break;

		case IZQUIERDA:
			m2step(1);
			m2step(1);
			m2step(1);
			m2step(1);
			m2step(1);
			m2step(1);

			break;

		case DERECHA:
			m2step(0);
			m2step(0);
			m2step(0);
			m2step(0);
			m2step(0);
			m2step(0);

			break;


		default:
			break;
		}
		}
		Ready();
		estado = ESPERANDO;
		break;

	case FINALIZADO:

		break;
	}
}


void testServo( void ){
	static uint8_t q = 0;
	q = GetKey();
	switch(q){
	case 1:
		Grip(ABRIR);
		break;
	case 2:
		Grip(CERRAR);
		break;
	case 3:
		Grip(SUBIR);
		break;
	case 4:
		Grip(BAJAR);
		break;
	}
}

void teststepper ( void ){

	static uint8_t k = 0, a = 0;
	static uint16_t  x = 0, y = 0;
	k = GetKey();

	if(k == 255){
		k = a;
	}
	switch(k){
		case 1:
			line(1200, 1050);
			break;
		case 2:
			PosicionarEn_Origen();
			break;
		case 3:
			line(0,0);
			break;
	}
	return;
}


void Impresora( void ){
	static uint8_t estado = 0;
	uint8_t aux;

	switch( estado ){

	case ESPERANDO:
		aux = Pop_RX();
		if( aux == '#' ){		//Si llega el comienzo de una linea
			estado = RECIBIENDO;
			sofar = 0;			//Posiciono el flag de buffer al comienzo del mismo
		}
		break;

	case RECIBIENDO:
		aux = Pop_RX();
		if( aux != 255 && aux != '$' ){	//Si hay dato y no es el final de trama
			buffer[sofar] = aux;		//Lo guardo
			sofar++;					//Aumento el flag
		}
		if( aux == '$' ){				//Si llega el final de trama
			buffer[sofar] = ' ';
			sofar++;
			buffer[sofar] = '\n';
			sofar++;
			estado = IMPRIMIENDO;
		}
		break;

	case IMPRIMIENDO:
		ProcessCommand();
		Ready();
		estado = ESPERANDO;
		break;

	case FINALIZADO:

		break;
	}
}


