#include "PR_PWM.h"
#include "DR_PWM.h"


void SetPWM_MatchValue( uint8_t match, uint32_t tiempo ){
	flagPWM = 1;
	PWM_Match = match;
	PWM_Valor = tiempo;

}
