/*

 * PR_CNC.h
 *
 *  Created on: 10 de may. de 2017
 *      Author: santi
 */

#ifndef PR_CNC_H_
#define PR_CNC_H_
#include "DR_tipos.h"
#include "DR_MPP.h"
#include "PR_Timer.h"
#include "math.h"
#include "string.h"
#include "stdlib.h"

#define M1_STEP 		54
#define M1_DIR  		55
#define M1_ENA  		38

#define M2_STEP 		60
#define M2_DIR  		61
#define M2_ENA  		56

// limit switches
#define SWITCH1 		3
#define SWITCH2 		14


#define ARC_CW          1
#define ARC_CCW         -1
// Arcs are split into many line segments.  How long are the segments?
#define MM_PER_SEGMENT  10

#define MAX_BUF        	100  // Largo del buffer de almacenamiento
#define STEPS_PER_TURN 	400  // depends on your stepper motor.  most are 200.
#define MIN_STEP_DELAY 	50
//#define MAX_FEEDRATE   	(1000000/MIN_STEP_DELAY)
//#define MIN_FEEDRATE   	0.01

#define MAX_FEEDRATE   	10000
#define MIN_FEEDRATE   	1000

#define BAUD 			0
#define PI 				3

extern 	int8_t 		buffer[MAX_BUF];
extern 	uint32_t 	step_delay;
extern	uint8_t   	sofar;

/**
 * First thing this machine does on startup.  Runs only once.
 */
void InicializarImpresora( void );

void PosicionarEn_Origen( void );
/**
 * Set the logical position
 * @input npx new position x
 * @input npy new position y
 */
void Posicion( int16_t npx, int16_t npy);
void Ready( void );				// * prepares the input buffer to receive a new message and tells the serial connected device it is ready for more.
void Pause( uint32_t );			// * Read the input buffer and find any recognized commands.  One G or M command per line.
void ProcessCommand( void );

/**
 * Look for character /code/ in the buffer and read the float that immediately follows it.
 * @return the value found.  If nothing is found, /val/ is returned.
 * @input code the character to look for.
 * @input val the return value if /code/ is not found.
 **/
int32_t parsenumber(uint8_t code, int32_t val);

/**
 * Set the feedrate (speed motors will move)
 * @input nfr the new speed in steps/second
 */
void feedrate( uint32_t nfr);

/**
 * Uses bresenham's line algorithm to move both motors
 * @input newx the destination x position
 * @input newy the destination y position
 **/
void line( uint32_t newx, uint32_t newy );


// devuelve angulo de dy/dx como valor entre 0 a 2PI
int16_t atan3( int16_t dy , int16_t dx );

// This method assumes the limits have already been checked.
// This method assumes the start and end radius match.
// This method assumes arcs are not >180 degrees (PI radians)
// cx/cy - center of circle
// x/y - end position
// dir - ARC_CW or ARC_CCW to control direction of arc
void arc(int32_t cx, int32_t cy, int32_t x, int32_t y, int8_t dir);

void where( void );				// * print the current position, feedrate, and absolute mode.
void help( void );				// * display helpful information

#endif /* PR_CNC_H_ */
