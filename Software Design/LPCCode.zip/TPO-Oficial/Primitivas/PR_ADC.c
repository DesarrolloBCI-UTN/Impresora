/*
 * PR_ADC.c
 *
 *  Created on: 30 de ago. de 2017
 *      Author: santi
 */

#include "PR_ADC.h"

uint16_t LeerADC( void ){
	uint16_t aux = 0;
	aux = ValorADC;
	ValorADC = 0;
	return aux;
}
