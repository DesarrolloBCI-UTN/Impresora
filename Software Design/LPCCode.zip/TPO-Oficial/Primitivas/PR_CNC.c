/*
 * PR_CNC.c
 *
 *  Created on: 19 de jun. de 2017
 *      Author: santi
 */

#include "PR_CNC.h"
#include "DR_MPP.h"

#define 	ORIGEN				0,0

int8_t  	buffer[MAX_BUF];  	// Donde se almacenan las lineas hasta que llega una nueva
uint8_t   	sofar;      		// flag del buffer
int32_t 	px, py;				// posición

// velocidades
uint8_t 	fr = 0; 	 		// human version
uint32_t 	step_delay = 10;	// machine version

uint8_t 	mode_abs=1;	   		// Modo de desplazamiento


/**
 * First thing this machine does on startup.  Runs only once.
 */
void InicializarImpresora( void ) {
	Inicializar_MPP( );
	Inicializar_Servos();

	PosicionarEn_Origen();
}

void PosicionarEn_Origen( void ){
	uint8_t X = 1, Y = 1;
	while( X & Y ){
		m1step(0);
		X = GetPIN( XMIN, ALTO );
		m2step(0);					//va hasta los fines de carrera
		Y = GetPIN( YMIN, ALTO );
	}
	while(X){
		m1step(0);
		X = GetPIN( XMIN, ALTO );
	}
	while(Y){
		m2step(0);					//va hasta los fines de carrera
		Y = GetPIN( YMIN, ALTO );
	}
	Posicion(ORIGEN);
}


/**
 * Set the logical position
 * @input npx new position x
 * @input npy new position y
 */
void Posicion(int16_t npx, int16_t npy) {
	px = npx;
	py = npy;
}

/**
 * prepares the input buffer to receive a new message and tells the serial connected device it is ready for more.
 */
void Ready() {
	sofar = 0;  				// clear flag buffer
	Push_TX('>');  				// comando para recibir nueva linea
}

void Pausa( uint32_t ms ) {		//desactivo motores y enciendo timers

}

/**
 * Read the input buffer and find any recognized commands.  One G or M command per line.
 */
void ProcessCommand( void )
{
  uint32_t i;
  int8_t cmd = parsenumber('G',-1);
  int8_t valor;
  switch(cmd) {
  case  0:
  case  1: { // line
    //feedrate(parsenumber('F', fr ));
	  valor = parsenumber('Z', 0);
	  if(valor != 0){
		  if( valor == 1 ){
			  Grip(BAJAR);
			  for(i = 0; i < 1000000; i++){};
		  }
		  if( valor == 2 ){
			  Grip(SUBIR);
		  }
	  }

	  line( parsenumber('X',px ),
			parsenumber('Y',py ));
    break;
    }
  case 2:
  case 3: {  // arc
      //feedrate(parsenumber('F',fr));
      arc(parsenumber('I',(mode_abs?px:0)) + (mode_abs?0:px),
          parsenumber('J',(mode_abs?py:0)) + (mode_abs?0:py),
          parsenumber('X',(mode_abs?px:0)) + (mode_abs?0:px),
          parsenumber('Y',(mode_abs?py:0)) + (mode_abs?0:py),
          (cmd==2) ? -1 : 1);
      break;
    }
  case  4:  Pausa(parsenumber('P',0)*1000);  break;  // dwell
  case 90:  mode_abs=1;  break;  // absolute mode
  case 91:  mode_abs=0;  break;  // relative mode
  case 92:  // set logical position
    Posicion( parsenumber('X',0),
              parsenumber('Y',0) );
    break;
  default:  break;
  }

  cmd = parsenumber('M',-1);

  switch(cmd) {
  case 18:
	  motpp_disable(MotorX);
	  motpp_disable(MotorY);
	  break;
  case 100:  help();  break;
  case 114:  where();  break;
  default:  break;
  }
}


/**
 * Look for character /code/ in the buffer and read the float that immediately follows it.
 * @return the value found.  If nothing is found, /val/ is returned.
 * @input code the character to look for.
 * @input val the return value if /code/ is not found.
 **/
int32_t parsenumber(uint8_t code, int32_t val) {
  int8_t *ptr = buffer;
  int32_t valor;
  if( code == 'Z' ){
	  while( *ptr != '\n' ){				//mientras no termine la linea
	      if( *(ptr) == code ){				//si el codigo es el que busco Ej X
	      	if( *(ptr+1) == '-' ){
	      		return 1;
	      	}
	      	else{
	      		return 2;
	      	}
	      }
	      ptr = strchr(ptr,' ');				//busco el proximo codigo
	      ptr++;
	  }
  }
  while( *ptr != '\n' ){				//mientras no termine la linea
    if( *(ptr) == code ){				//si el codigo es el que busco Ej X
    	if( *(ptr+3) == '.' ){			//evaluo si tiene decimales(funciona solo si hay 2 unidades enteras)
    		valor= (atoi(ptr+4)/100000);
    		valor+= atoi(ptr+1)*10;
    		return valor;
    	}
      return atoi(ptr+1);				//devuelvo el valor obtenido
    }
    ptr = strchr(ptr,' ');				//busco el proximo codigo
    ptr++;
  }
  return val;							//devuelvo el valor por defecto(se usa para quedarse en el mismo lugar en caso que no encuentre un valor nuevo que procesar)
}

/**
 * Set the feedrate (speed motors will move)
 * @input nfr the new speed in steps/second
 */
void feedrate( uint32_t nfr) {
	if(fr==nfr) return;  // same as last time?  quit now.

	if(nfr>MAX_FEEDRATE || nfr<MIN_FEEDRATE) {  // don't allow crazy feed rates
		return;
	}
//  step_delay = 1000000/nfr;
	T0MR0 = nfr;
	T0TCR = 0x00000002; 	// Apago y reseteo el temporizador
	T0TCR = 0x00000001;		// Enciendo el temporizador
	fr = nfr;
}

/**
 * Uses bresenham's line algorithm to move both motors
 * @input newx the destination x position
 * @input newy the destination y position
 **/
void line(uint32_t newx,uint32_t newy) {
  uint32_t i;
  int16_t over = 0;
  int16_t dx  = newx-px;		//diferencia hasta la posicion deseada
  int16_t dy  = newy-py;
  int8_t dirx = dx>0?1:0;		//defino sentido de giro
  int8_t diry = dy>0?1:0;

  dx = abs(dx);					//tomo distancia en valor absoluto
  dy = abs(dy);

  if(dx>dy) {							//si la distancia en x es mas grande
    over = dx/2;
    for(i=0; i<dx; i++) {
    	m1step(dirx);
    	over += dy;
    	if( over >= dx ) {
    		over -= dx;
    		m2step(diry);
    	}
    }
  }
  else {
	  over = dy/2;
	  for(i=0; i<dy; ++i) {
		  m2step(diry);
		  over += dx;
		  if(over >= dy) {
			  over -= dy;
			  m1step(dirx);
		  }
	  }
  }

  px = newx;
  py = newy;
}


// devuelve angulo de dy/dx como valor entre 0 a 2PI
int16_t atan3(int16_t dy,int16_t dx) {
  int16_t a = atan2(dy,dx);
  if(a<0) a = (PI*2)+a;
  return a;
}


// This method assumes the limits have already been checked.
// This method assumes the start and end radius match.
// This method assumes arcs are not >180 degrees (PI radians)
// cx/cy - center of circle
// x/y - end position
// dir - ARC_CW or ARC_CCW to control direction of arc
void arc(int32_t cx, int32_t cy, int32_t x, int32_t y, int8_t dir) {
  // get radius
	int32_t dx = px - cx;
	int32_t dy = py - cy;
	int32_t radius=sqrt(dx*dx+dy*dy);

  // find angle of arc (sweep)
	int32_t angle1=atan3(dy,dx);
	int32_t angle2=atan3(y-cy,x-cx);
	int32_t theta=angle2-angle1;

  if(dir>0 && theta<0) angle2+=2*PI;
  else if(dir<0 && theta>0) angle1+=2*PI;

  theta=angle2-angle1;

  // get length of arc
  // int32_t circ=PI*2.0*radius;
  // int32_t len=theta*circ/(PI*2.0);
  // simplifies to
  int32_t len = abs(theta) * radius;

  int8_t i, segments = ceil( len * MM_PER_SEGMENT );

  int32_t nx, ny, angle3, scale;

  for(i=0;i<segments;++i) {
    // interpolate around the arc
    scale = ((float)i)/((float)segments);

    angle3 = ( theta * scale ) + angle1;
    nx = cx + cos(angle3) * radius;
    ny = cy + sin(angle3) * radius;
    // send it to the planner
    line(nx,ny);
  }

  line(x,y);
}

/**
 * envia ubicacion actual, feedrate y modo absoluto
 */
void where() {
//
//  TransmitirSerie("X");
//  TransmitirSerie(px);
//  TransmitirSerie("Y");
//  TransmitirSerie(&py);
//  TransmitirSerie("F");
//  TransmitirSerie(fr);
//  TransmitirSerie(mode_abs?"ABS":"REL");
}


/**
 * display helpful information
 */
void help() {
//  Serialprint(F("GcodeCNCDemo2AxisV1 "));
//  Serialprintln("VERSION");
//  Serialprintln(F("Commands:"));
//  Serialprintln(F("G00 [X(steps)] [Y(steps)] [F(feedrate)]; - line"));
//  Serialprintln(F("G01 [X(steps)] [Y(steps)] [F(feedrate)]; - line"));
//  Serialprintln(F("G02 [X(steps)] [Y(steps)] [I(steps)] [J(steps)] [F(feedrate)]; - clockwise arc"));
//  Serialprintln(F("G03 [X(steps)] [Y(steps)] [I(steps)] [J(steps)] [F(feedrate)]; - counter-clockwise arc"));
//  Serialprintln(F("G04 P[seconds]; - delay"));
//  Serialprintln(F("G90; - absolute mode"));
//  Serialprintln(F("G91; - relative mode"));
//  Serialprintln(F("G92 [X(steps)] [Y(steps)]; - change logical position"));
//  Serialprintln(F("M18; - disable motors"));
//  Serialprintln(F("M100; - this help message"));
//  Serialprintln(F("M114; - report position and feedrate"));
//  Serialprintln(F("All commands must end with a newline."));
}
