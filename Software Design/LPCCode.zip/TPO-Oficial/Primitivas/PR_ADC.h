/*
 * PR_ADC.h
 *
 *  Created on: 30 de ago. de 2017
 *      Author: santi
 */

#ifndef PR_ADC_H_
#define PR_ADC_H_

#include "DR_adc.h"

uint16_t LeerADC( void );


#endif /* PR_ADC_H_ */
