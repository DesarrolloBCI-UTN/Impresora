/*
 * PR_Servos.h
 *
 *  Created on: 31 de oct. de 2017
 *      Author: santi
 */

#ifndef PR_SERVOS_H_
#define PR_SERVOS_H_

#include "PR_PWM.h"
#include "DR_tipos.h"

#define 	ALTURA		2
#define 	GRIP 		4

#define		ABRIR		0
#define		CERRAR		1
#define		SUBIR		2
#define		BAJAR		3

#define		ABIERTO		450
#define		CERRADO		300
#define		ARRIBA		300
#define		ABAJO		600
void Grip ( uint8_t );

#endif /* PR_SERVOS_H_ */
