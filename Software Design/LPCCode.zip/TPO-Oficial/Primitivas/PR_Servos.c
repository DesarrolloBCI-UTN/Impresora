/*
 * PR_Servos.c
 *
 *  Created on: 31 de oct. de 2017
 *      Author: santi
 */

#include "PR_Servos.h"



void Grip ( uint8_t accion ){
	switch(accion){
	case ABRIR:
		SetPWM_MatchValue(GRIP, ABIERTO);
		break;

	case CERRAR:
		SetPWM_MatchValue(GRIP, CERRADO);
		break;

	case SUBIR:
		SetPWM_MatchValue(ALTURA, ARRIBA);
		break;

	case BAJAR:
		SetPWM_MatchValue(ALTURA, ABAJO);
		break;
	}
}
