/*
 * PR_PWM.h
 *
 *  Created on: 16 de ago. de 2017
 *      Author: santi
 */

#ifndef PR_PWM_H_
#define PR_PWM_H_

#include "DR_tipos.h"
#include "DR_PWM.h"

extern uint8_t flagPWM;
extern uint8_t PWM_Match;
extern uint32_t PWM_Valor;

void SetPWM_MatchValue( uint8_t , uint32_t );


#endif /* PR_PWM_H_ */
