/*
 * DR_PWM.c
 *
 *  Created on: 14 de ago. de 2017
 *      Author: santi
 */

#include "DR_PWM.h"
#include "DR_PLL.h"
#include "DR_gpio.h"
#include "DR_EINT.h"

uint8_t PWM_Match;
uint32_t PWM_Valor;
uint8_t flagPWM = 0;

void PWM_inicializacion( void ){

	PWMIR = 0x073F;			//configuro interrupcionese
	PWMTCR = 0x00;
	PWMCTCR = 0x00;
	PWMMCR = 0x00;
	PWMCCR = 0x00;
	PWMPCR = 0x00;
	PWMLER = 0x00;
	PWMPR = 49;				//Con este prescaler, 1000000 es un segundo

//Configuracion match 0,2,3,4
	PWMMCR |= 1<<1;			//reset match 0
	PWMMR0 = 10000;			//establece el periodo del PWM
	PWMMR2 = 450;
	PWMMR4 = 300;

	PWMLER = 0x1D;			//sirve para actualizar el registro de cada match seteado en 1

//	PWMPCR |= 1<<9;			//habilito salida PWM1
	PWMPCR |= 1<<10;		//habilito salida PWM2
//	PWMPCR |= 1<<11;		//habilito salida PWM3
	PWMPCR |= 1<<12;		//habilito salida PWM4

	PWMTCR |=	1<<1;		//se resetea el contador
	PWMTCR = 0x09;			//se habilitan contador y PWM
}

void PWM_update ( void ){
	if( flagPWM ){
		flagPWM = 0;
		if( PWM_Match < 4 ){
			PWM[6 + PWM_Match] = PWM_Valor;
		}
		else{
			PWM_Match -= 4;
			PWM[ 16 + PWM_Match ] = PWM_Valor;
			PWM_Match += 4;
		}
		PWMLER |= ( 1 << PWM_Match );
	}
}
