 /*******************************************************************************************************************************//**
 *
 * @file		DR_EINT.c
 * @brief		Interrupciones externas
 * @date		Fecha de creacion del archivo 09-06-16
 * @author		Marcelo, Trujillo
 *
 **********************************************************************************************************************************/

 /***********************************************************************************************************************************
  *** INCLUDES
  **********************************************************************************************************************************/
#include "DR_EINT.h"
#include "Inicializacion.h"
#include "PR_Timer.h"
#include "Infotronic.h"

 /***********************************************************************************************************************************
  *** DEFINES PRIVADOS AL MODULO
  **********************************************************************************************************************************/
#define		EINT0_PIN		2,10 		//SW1
#define		EINT1_PIN		2,11		//Entrada Digital 2
#define		EINT2_PIN		2,12		//Expansion 17
#define		EINT3_PIN		2,13		//SW4

 /***********************************************************************************************************************************
  *** MACROS PRIVADAS AL MODULO
  **********************************************************************************************************************************/

 /***********************************************************************************************************************************
  *** TIPOS DE DATOS PRIVADOS AL MODULO
  **********************************************************************************************************************************/

 /***********************************************************************************************************************************
  *** TABLAS PRIVADAS AL MODULO
  **********************************************************************************************************************************/

 /***********************************************************************************************************************************
  *** VARIABLES GLOBALES PUBLICAS
  **********************************************************************************************************************************/

 /***********************************************************************************************************************************
  *** VARIABLES GLOBALES PRIVADAS AL MODULO
  **********************************************************************************************************************************/
static uint8_t flagEINT[4] = {0, 0, 0, 0};
 /***********************************************************************************************************************************
  *** PROTOTIPO DE FUNCIONES PRIVADAS AL MODULO
  **********************************************************************************************************************************/

  /***********************************************************************************************************************************
  *** FUNCIONES PRIVADAS AL MODULO
  **********************************************************************************************************************************/

  /***********************************************************************************************************************************
  *** FUNCIONES GLOBALES AL MODULO
  **********************************************************************************************************************************/
 void EXT0_Inicializacion(void)
{

	 ICE_EINT0;
	 SetPINSEL( EINT0_PIN , PINSEL_FUNC1 ); 	// Configuro el P2[10] (SW1) para que trabaje como EINT0 esto debe hacerse con
	                                     	 	// la Interr deshabilitada Pag 25

//	 EXTMODE0_F;                         		// Configuro la interrupcion externa 0 por flanco
                                         	 	// EXTPOLAR0_P; // si quiero por flanco positivo debo cambiarlo en EXTPOLAR
	 ISE_EINT0;                      	 		// Habilito Interrupcion Externa 0
}

void EXT1_Inicializacion(void)
{
	ICE_EINT1;
	SetPINSEL( EINT1_PIN , PINSEL_FUNC1 );
	EXTMODE1_F;
	ISE_EINT1;
}

void EXT2_Inicializacion(void)
{
	ICE_EINT2;									//Desactivo interrupcion
	SetPINSEL( EINT2_PIN , PINSEL_FUNC1 );		//Configuro el P2[12] (EXP17) para que trabaje como EINT2
//	EXTMODE2_F;									// Configuro la interrupcion externa 2 por flanco
	EXTPOLAR2_P;
	ISE_EINT2;									// Habilito Interrupcion
}

void EXT3_Inicializacion(void)
{
	ICE_EINT3;
	SetPINSEL( EINT3_PIN , PINSEL_FUNC1 );
	EXTMODE3_F;
	ISE_EINT3;
}
void EINT0_IRQHandler(void)
{
	CLR_EINT0;									// borro el flag EINT0 de interrupcion externa 0 del registro EXTINT
	if( flagLed[Rojo] ){
		SetPIN(LedRojo, ON);
		flagLed[Rojo] = 0;
	}
	else {
		SetPIN(LedRojo, OFF);
		flagLed[Rojo] = 1;
	}
	flagEINT[0]++;
	CLR_EINT0;
}

void EINT1_IRQHandler(void)
{
	CLR_EINT1;									//Borro flag de interrupcion
}

void EINT2_IRQHandler(void)
{
	CLR_EINT2;									//Borro flag de interrupcion
	Emergency_STOP();
}

void EINT3_IRQHandler(void)
{
	CLR_EINT3;									//Borro flag de interrupcion
	if( flagLed[Rojo] ){
		SetPIN(LedRojo, ON);
		flagLed[Rojo] = 0;
	}
	else {
		SetPIN(LedRojo, OFF);
		flagLed[Rojo] = 1;
	}
}

void Emergency_STOP (void)
{

}

void EINT0_Delay( void ){
	if( flagEINT[0] >> 0 ){
		ICE_EINT0;
		flagEINT[0]++;
		if(flagEINT[0] == 999999 ){
			CLR_EINT0;
		}
		flagEINT[0]%=100;
	}
	else{ ISE_EINT0; }
}

