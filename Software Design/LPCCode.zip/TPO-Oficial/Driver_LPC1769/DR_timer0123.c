/*******************************************************************************************************************************//**
 *
 * @file		DR_timer0123.c
 * @brief		Descripcion del modulo
 * @date		5 de jul. de 2016
 * @author		Ing. Marcelo Trujillo
 *
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** INCLUDES
 **********************************************************************************************************************************/
#include "DR_timer0123.h"
#include "DR_PLL.h"
#include "DR_EINT.h"
#include "DR_gpio.h"
#include "DR_MPP.h"


/***********************************************************************************************************************************
 *** DEFINES PRIVADOS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** MACROS PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** TIPOS DE DATOS PRIVADOS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** TABLAS PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** VARIABLES GLOBALES PUBLICAS
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** VARIABLES GLOBALES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

/***********************************************************************************************************************************
 *** PROTOTIPO DE FUNCIONES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

 /***********************************************************************************************************************************
 *** FUNCIONES PRIVADAS AL MODULO
 **********************************************************************************************************************************/

 /***********************************************************************************************************************************
 *** FUNCIONES GLOBALES AL MODULO
 **********************************************************************************************************************************/
/**

 *
	\fn  Nombre de la Funcion
	\brief Descripcion
 	\author Ing. Marcelo Trujillo
 	\date 5 de jul. de 2016
 	\param [in] parametros de entrada
 	\param [out] parametros de salida
	\return tipo y descripcion de retorno
*/


/**
 \fn  void InicTimeo0 (void)
 \brief Inicializa timer 0 para trabajar en captura del canal 0 generando interrupciones
 \author CATEDRA INFO2
 \date: - Nov2012
 \param  void
 \return void
*/
void InicTimer0(void){
	SetPINSEL( 1 , 26 , 3 );			//!< SW13 P1.26 como CAP0.0
	SetMODE( 1 , 26 , 0 );			//!< Configurar pin mode como pull up para P1.26


	PCONP |= 1 << 1; 		// Habilitar Timer 0
	PCLKSEL0 |= 1 << 2; 	// Clock for timer PCLK = CCLK Selecciono clock
	T0MR0 = 150000;			// Configuro el tiempo del match 0
//	T0MR1 = 100000000;		// Configuro el tiempo del match 1
	T0MCR = 0x00000003;		// (0x0019)Match 0 interrumpe y Match 1 interrumpe y resetea timer
							// (0x0007)Match 0 interrumpe y resetea timer
	T0CTCR = 0x00000000;	// Modo Timer
//	T0CCR &= ~(0x00000007);	// Pone en cero los bits de control del CAP0.0
	ISER0 |=(0x01 << 1); 	// Habilito Interrupcion TIMER0
	T0TCR = 0x00000002; 	// Apago y reseteo el temporizador
	T0TCR = 0x00000001;		// Enciendo el temporizador

}

void InicTimer1(void){

	PCONP |= 1 << 2; 		// Habilitar Timer 1
	PCLKSEL0 |= 1 << 4; 	// Clock for timer PCLK = CCLK Selecciono clock
	T1MR0 = 150000;			// Configuro el tiempo del match 0
//	T1MR1 = 100000000;		// Configuro el tiempo del match 1
	T1MCR = 0x00000003;		// (0x0019)Match 0 interrumpe y Match 1 interrumpe y resetea timer
							// (0x0007)Match 0 interrumpe y resetea timer
	T1CTCR = 0x00000000;	// Modo Timer
//	T1CCR &= ~(0x00000007);	// Pone en cero los bits de control del CAP0.0
	ISER0 |=(0x01 << 2); 	// Habilito Interrupcion TIMER1
	T1TCR = 0x00000002; 	// Apago y reseteo el temporizador
	T1TCR = 0x00000001;		// Enciendo el temporizador

}

/**
 * \fn void TIMER0_IRQHandler (void)
 * \brief ISR de timer0
 * \details Limpia flag y guarda captura Ch0 para ser usada en otra parte del programa
 * \author GOS
 * \date   2014.05.06
 * \param [in] void
 * \return void
 * */
void TIMER0_IRQHandler (void)
{
	if( ( T0IR & 0x00000001 ) ){ 			// Si interrumpio match 0
		if( e_mot[MotorX] != 2 ){
			e_mot[MotorX] = 1;
		}
		T0IR |= 0x00000001;			// Borro flag del Match 0
	}
}

void TIMER1_IRQHandler (void)
{
	if( ( T1IR & 0x00000001 ) ){ 			// Si interrumpio match 0
		if( e_mot[MotorY] != 2 ){
			e_mot[MotorY] = 1;
		}
		T1IR |= 0x00000001;			// Borro flag del Match 0
	}
}
