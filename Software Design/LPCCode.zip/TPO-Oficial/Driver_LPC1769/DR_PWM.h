/*
 * DR_PWM.h
 *
 *  Created on: 14 de ago. de 2017
 *      Author: santi
 */

#ifndef DR_PWM_H_
#define DR_PWM_H_

#include "DR_tipos.h"

#define		PWM 		( ( __RW uint32_t  * ) 0x40018000UL )
#define		PWMIR		PWM[0]
#define		PWMTCR		PWM[1]
#define		PWMTC		PWM[2]
#define		PWMPR		PWM[3]
#define		PWMPC		PWM[4]
#define		PWMMCR		PWM[5]
#define		PWMMR0		PWM[6]
#define		PWMMR1		PWM[7]
#define		PWMMR2		PWM[8]
#define		PWMMR3		PWM[9]
#define		PWMCCR		PWM[10]
#define		PWMCR0		PWM[11]
#define		PWMCR1		PWM[12]
#define		PWMCR2		PWM[13]
#define		PWMCR3		PWM[14]
#define		PWMMR4		PWM[16]
#define		PWMMR5		PWM[17]
#define		PWMMR6		PWM[18]
#define		PWMPCR		PWM[19]
#define		PWMLER		PWM[20]
#define		PWMCTCR		PWM[21]


void PWM_inicializacion( void );

void PWM_update( void );

#endif /* DR_PWM_H_ */
