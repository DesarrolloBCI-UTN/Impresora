/*
 * DR_Servos.h
 *
 *  Created on: 31 de oct. de 2017
 *      Author: santi
 */

#ifndef DR_SERVOS_H_
#define DR_SERVOS_H_

#include "Infotronic.h"

#define 	ServoAltura		EXP3	//PWM1.2
#define 	ServoGrip	EXP4	//PWM1.4

void Inicializar_Servos( void );

#endif /* DR_SERVOS_H_ */
