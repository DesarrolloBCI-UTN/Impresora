/*
 * DR_Servos.c
 *
 *  Created on: 31 de oct. de 2017
 *      Author: santi
 */
#include "DR_gpio.h"
#include "DR_pinsel.h"
#include "PR_Servos.h"

void Inicializar_Servos( void ){
	PINSEL3 |= 1<<9;	FIO1DIR |= 1<<20;	//EXP4 como PWM y salida
	PINSEL3 |= 1<<15;	FIO1DIR |= 1<<23;	//EXP3 como PWM y salida

	Grip(SUBIR);
	Grip(ABRIR);
}
